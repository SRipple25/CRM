# Phillips CRM

Your HubSpot replacement. It works two ways:

| | **Local mode** (now) | **Live mode** (when you're ready) |
|---|---|---|
| Who uses it | Just you, on this computer | The whole team, from anywhere |
| Where data lives | Your browser | A Firebase project |
| Email | Opens a filled-in Gmail draft and logs it | Sent automatically from Gmail |
| Workflows and sequences | Run as a preview: tasks, tags, and enrollments are real; emails are logged as "would send" | Run for real every 5 minutes |
| Setup | None | About 30 minutes (steps below) |

## Use it on your own computer (local mode)

1. Download `index.html` and save it somewhere permanent, like Documents.
2. Double-click it to open it in **Chrome, Edge, or Safari**. (The preview inside Claude can't save anything.)
3. Choose **Start with my own data**. Or click **Explore with sample data** first; your own data is kept separately and you can switch back and forth from Settings.
4. In **Settings**, check the firm name, your signature, the team, and each tier's quarterly fee and check-in window.
5. Fill it in: contacts, clients, fee plans, payments, deals, strategies, work.

**Back it up.** Your data lives only in this browser on this computer. Clearing browsing data, or switching browsers or computers, won't show it. Click **Back up now** in the top banner (it reminds you when it's been more than a week) and keep the file in Google Drive. **Restore from backup** brings it back on any computer.

**Trying out automations.** Turn on a workflow, then add a contact that matches it. Within a couple of seconds the preview engine enrolls them, creates the tasks, and logs each email it would have sent (marked "not sent") on their timeline. Sequences wait days between emails, so the **Automation log** has a **Run now** button to step through them. On a contact, **Replied** stops their sequence, the same thing the live engine does automatically when it sees a reply in your inbox.

**Emails** from a contact open as a Gmail draft with merge tags filled in and your signature added, and the email is logged on their timeline. **Mail app** uses your default email program instead, and **Just log it** records an email you sent some other way.

**Moving to live later.** Download a backup, do the setup below, sign in, then **Settings > Data > Import a backup**. Everything comes over: contacts, clients, revenue, history, templates, sequences, and workflows.

---

# Going live (whole team)

## 1. Create the Firebase project

1. Go to <https://console.firebase.google.com> and **Add project**. Name it something like `legacy-tax-crm` (keep it separate from the task board project). Google Analytics is not needed.
2. **Build > Firestore Database > Create database.** Choose **production mode** and a US region.
3. **Build > Authentication > Get started > Sign-in method > Google > Enable.**
4. **Project settings (gear) > General > Your apps > Web (`</>`)**. Register an app called `Phillips CRM`. Firebase shows a `firebaseConfig` block. Keep that tab open.

## 2. Lock it down

1. Open `firestore.rules`, replace the four example addresses with the Google accounts your team signs in with, and keep the format exactly.
2. Firebase console **Firestore Database > Rules**, paste the whole file, **Publish**.

Only those accounts can see anything. Add someone later by editing this list and publishing again.

## 3. Put the CRM online

1. Open `index.html` in a text editor. Near the top of the `<script>` is `FIREBASE_CONFIG`. Replace the `PASTE...` values with the ones from step 1.4 and save.
2. Upload `index.html` to Tiiny.host (same as the task board). Note the address it gives you, e.g. `legacycrm.tiiny.site`.
3. Firebase console **Authentication > Settings > Authorized domains > Add domain** and enter that Tiiny address (no `https://`).
4. Visit the site and sign in with Google. You should see an empty CRM.

## 4. First things in the CRM

Open **Settings** and fill in:

- **Sender name** and **signature** (added to every automated email)
- **Team**: each person's name and email. Names fill the owner and assignee menus; emails link sign-ins to names and receive workflow notifications.
- **Pipeline stages** if you want different names. The defaults are New Lead, Discovery Call, Analysis Meeting, Engagement Sent, Signed, Lost.

Click **Save settings**, then **Load starter templates** for three templates, a 3 email "Website lead nurture" sequence, and a "New website lead" workflow (left off until you review it).

## 5. Set up the email engine

You need a **service account key** so the engine can read and write the database.

1. Firebase console **Project settings > Service accounts > Generate new private key**. A `.json` file downloads. Treat it like a password: it has full access to the CRM data.
   - If Google says key creation is blocked by an organization policy, your Workspace admin console has `iam.disableServiceAccountKeyCreation` turned on. Either have the admin turn it off for this project in Google Cloud console > IAM > Organization policies, or create the Firebase project under "No organization".
2. Signed in as the **Workspace account the emails should come from**, go to <https://script.google.com> and create a **New project**. Name it `Phillips CRM Engine`.
3. Delete the starter code, paste all of `Code.gs`, and save.
4. **Project Settings (gear)**:
   - **Time zone**: `(GMT-06:00) Central Time`. This controls the weekday 8:30am to 5pm sending window.
   - **Script properties > Add**: name `SERVICE_ACCOUNT_JSON`, value = open the downloaded `.json` file and paste its entire contents.
5. Back in the editor, choose the `setup` function in the toolbar and click **Run**. Approve the permissions (Google shows an "unverified app" screen because it is your own script: **Advanced > Go to Phillips CRM Engine**).
6. The execution log should say Firestore OK, Gmail OK, and that a 5 minute trigger is installed. The CRM dashboard's **Automation engine** card turns green within a few minutes.

Optional: run `sendTestEmail` to send yourself a test with your signature.

## 6. Turn on unsubscribe links and the website form

1. In Apps Script: **Deploy > New deployment > Select type: Web app**. Execute as **Me**, Who has access **Anyone**. Deploy and copy the URL (ends in `/exec`).
2. **Project Settings > Script properties**: add `WEBAPP_URL` with that URL. Unsubscribe links now appear in sequence emails.
3. In the CRM **Settings > Website form**, paste the same URL. Copy the HTML snippet shown there into the contact page on legacytax.us (or hand it to whoever manages the site). You can restyle the fields; keep the `name` attributes.

If you change `Code.gs` later: **Deploy > Manage deployments > edit (pencil) > Version: New version > Deploy**. The URL stays the same.

## 7. Test it end to end

1. Create a contact with your own personal email, source **Website form**.
2. Open **Workflows**, review "New website lead", and turn it on. (Or skip the workflow and use **Enroll** on the contact.)
3. Within about 5 minutes: email 1 lands in your inbox, a call task appears, and the timeline shows the send.
4. Reply to that email. On the next run the enrollment flips to **replied** and email 2 never goes out.
5. Click the unsubscribe link in the footer. The contact is marked **Unsubscribed**.

Run HubSpot in parallel for a week or two, then cancel it once you trust the engine.

---

## Clients

**Clients** is for the people and households you are taking care of (prospects stay in Contacts and Deals).

- **Make a client** from any contact (gold **Make client** button), from a Signed deal, or with **New client**. Link more people to the same client, such as a spouse or business partner.
- **Tier** (Silver, Gold, Platinum), **status** (Onboarding, Active, Paused, Former), advisor, client since, next review date.
- **Designations**: Real estate professional (REPS), Short-term rental (material participation), Business owner.
- **Strategies**: each one is Planned, In progress, Implemented, or On hold, with notes. Common ones are suggested as you type.
- **Work**: estate and will planning, company reorganizations, entity formation, studies, and so on. Each has a status, a due date, and whether Phillips or Providence Law is handling it.
- **Last contacted** updates when you log a call or meeting (on the client or any linked contact) or send them an email. Each tier has a check-in window (default Platinum 30 days, Gold 45, Silver 60; change it in Settings). Overdue clients are flagged on the Clients page and the dashboard.
- Every strategy, work, and tier change is recorded in the client's history. **Export** downloads the list as a CSV.

## Revenue

Every dollar the firm earns is a ledger entry tied to a client, and optionally to a company and a deal.

- **Fee plans** (on the client page) hold recurring fees: quarterly tier fees, monthly retainers, annual fees. Each payment comes up on the due list; click **Mark paid** to log it, or **Waive** it. When you add a plan that started in the past, tick the box to record earlier payments as already received.
- **Record** any other income: startup fees (with an option to split into two invoices 30 days apart), deal or project fees, hourly consulting, and commissions or referral fees. Set **Paid by** to the partner (fund, equipment program, lender) when someone other than the client pays you.
- Each entry is **Paid**, **Invoiced**, **Expected**, or **Waived**. Only Paid counts as collected; Invoiced and Expected show as outstanding or upcoming.
- **Client page**: lifetime, last 12 months, recurring per year, outstanding, a breakdown by type, fee plans, what's due, and the ledger.
- **Company and deal pages** show the money tied to them. A deal shows collected vs. the deal amount.
- **Revenue page**: collected this quarter and year to date, recurring per year, outstanding, next 90 days, a 12 month chart by type, top clients, who pays you, recurring by tier, everything due, and the full ledger with filters. **Export** downloads the ledger as a CSV for your bookkeeping.
- Set each tier's standard quarterly fee in **Settings > Client tiers** so new fee plans fill it in.

**Per project, monthly, and quarterly, tracked separately.** Clients and companies can both have fee plans (monthly retainers, quarterly fees, annual fees), and every ledger entry is tagged with how it's billed: **Per project**, **Monthly**, **Quarterly**, or **Annual**. Fee plan payments are tagged automatically by the plan's frequency; anything else you record defaults to Per project, and you can change it with the **Billed** field. The Revenue page's **How we're paid** section shows each one separately (collected this year, recurring per year, past due, and how many clients and companies pay that way), **Recurring fee plans** lists every plan grouped by monthly and quarterly, and the ledger can be filtered by billing type. Client and company pages show the same split for that relationship.

Everyone on the team list can see revenue.

## Advisory agreements (basis points, cash and equity)

For companies that use the firm as their advisor on redevelopment projects:

- On the company page, **Advisory agreement > Set up**: basis points per project (for example 150), the cash share at closing (default 50%; the rest is equity), scope, and notes such as how project value is defined.
- **+ Deal** on that company starts each project with those terms. Enter the project value and the form shows the total fee, the cash at closing, and the equity. Any single project can be adjusted, or switched back to a flat fee.
- When a project moves to **Signed**, the cash half is added to the revenue ledger as an **invoiced** advisory fee, and the equity half is tracked on the deal as **owed**. Click **Update** to record when it's issued, the ownership (units, class, percent), and its estimated value as it changes. Record cash that comes from the equity (distributions, refinance or sale proceeds) with **Distribution**, so it counts as collected revenue.
- The company page summarizes the relationship: projects advised, cash collected, equity held (estimated value and basis), and fees still in the pipeline. The **Revenue** page adds an **Equity held** total and an **Equity portfolio** table of every stake.

## Scheduled workflows (date-based triggers)

Besides "when something happens" triggers, a workflow can run on the calendar for clients:

- **Days before each new quarter**: e.g. 14 days before Jan 1, Apr 1, Jul 1, Oct 1
- **Days before a client's review date**
- **Days after a client signs**

Filter by tier, by clients with a quarterly fee plan, and skip paused or former clients. Each runs once per client per occurrence, using the client's primary contact; tasks assigned to **Advisor / owner** go to the client's advisor. New merge tags: `{{nextQuarter}}` (Q1 2027), `{{quarterStartDate}}` (January 1), `{{clientName}}`, `{{tier}}`, `{{advisor}}`, `{{reviewDate}}`.

The **Quarterly meeting invite** button on the Workflows page adds a ready-made workflow (turned off so you can review the email): two weeks before each quarter, quarterly clients get a meeting invite and their advisor gets a task to book it. The live engine checks date triggers hourly; the local preview engine checks every 10 minutes.

## AI assistant

The **Ask AI** button (bottom right) opens a chat with Claude. Ask it to set things up ("create a workflow so quarterly clients get an email 2 weeks before each quarter"), draft emails, or answer questions about your clients, deals, and revenue.

- **It never changes anything on its own.** Every change comes back as a card you can review; nothing is saved until you click **Approve**. Emails it drafts open in Gmail for you to send.
- **Setup:** create an API key at console.anthropic.com (API keys) and paste it in **Settings > AI assistant** or in the panel. Usage is billed by Anthropic per request, separate from a Claude subscription. The key is kept in that browser only, not in the CRM data or backups; each team member adds their own.
- **Privacy:** to answer, the assistant sends a summary of your CRM data (clients, companies, open deals, templates, workflows, revenue totals) to Anthropic with each request.
- **Writing style:** Settings > AI assistant has a style box. It defaults to your voice (warm and direct, no hyphens or em dashes, no filler) and you can edit it.

## How the automation works

- **Triggers** (contact created, website form submitted, tag added, deal created, deal moves to a stage) are written by the CRM as events. Every 5 minutes the engine matches them to active workflows and schedules each step. **Wait** steps push everything after them later.
- **Workflow steps**: send email, enroll in sequence, create task, add or remove tag, move deal, notify a team member, stop all sequences, wait.
- **Sequences** send timed emails from your Gmail account. Before every send after the first, the engine checks your inbox for a reply from that contact and stops if it finds one. It also watches for bounce notices. Leave a step's subject blank to send it as `Re:` the first email.
- **One-off emails** from a contact record go through the same queue, so they show in the timeline and can be scheduled.
- Everything the engine did is in **Automation log**: what is scheduled, what was sent, and any errors with a Retry button.
- A workflow runs once per contact (or deal) unless you tick "allow more than once". Workflows that trigger each other stop after 3 levels to prevent loops.

## Limits worth knowing

- **Sending volume**: Google Workspace allows roughly 1,500 automated recipients a day per account. The engine stops sending for the day when fewer than 10 remain and resumes the next day. It also caps each 5 minute run at 40 emails, so a big batch drips out over a few runs.
- **Timing**: actions land within about 5 minutes of the trigger, not instantly.
- **Replies** are detected in the inbox of the account running the engine. If a sequence sends as an alias (for example Todd), make sure replies to that alias land in the same mailbox.
- **No open or click tracking.** HubSpot has it; this does not. Reply detection is what stops sequences.
- **Firebase free tier** covers a firm your size comfortably. The engine reads only items that are due, so an idle run costs about 4 reads.

## Files

```
index.html          the CRM (built from src/ by build.sh)
apps-script/Code.gs the automation engine
firestore.rules     database access rules
src/                editable source: styles.css, core.js, views.js, clients.js, revenue.js, advisory.js, local.js, ai.js, auto.js, dates.js, boot.js
build.sh            rebuilds index.html from src/
```
